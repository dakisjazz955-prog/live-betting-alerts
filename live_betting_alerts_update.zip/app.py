"""Live Betting Alerts: test notifications + API-Sports football in-play double finder.

Mobile tab must stay open for automatic notifications. Server web push is not enabled.
No wagers are ever placed. Key stays in Render environment, never in browser.
"""
import os
from flask import Flask, jsonify, Response, render_template_string
from live_odds import get_live_snapshot

app = Flask(__name__)

PAGE = r'''<!doctype html>
<html lang="el">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#111b20">
<title>Live Betting Alerts</title>
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
*{box-sizing:border-box}body{margin:0;background:#101b20;color:#eef5f3}
main{max-width:620px;margin:auto;padding:24px 18px 52px}
.eyebrow{font-size:12px;letter-spacing:2px;color:#79e5b8;font-weight:800}
h1{font-size:30px;line-height:1.13;letter-spacing:-.7px;margin:24px 0 10px}
h2{font-size:18px;margin:0 0 10px}p{line-height:1.55;color:#b8c8c9}
.card{border:1px solid #33454a;background:#1b2a2f;border-radius:18px;padding:18px;margin-top:16px}
.tag{display:inline-block;padding:5px 9px;background:#354146;border-radius:14px;font-size:12px;color:#e3ecdf}
.muted{font-size:13px;color:#b6c5c7}.big{font-size:22px;font-weight:800;margin:10px 0}
button{width:100%;cursor:pointer;border:0;padding:14px;margin-top:9px;border-radius:11px;font-weight:800;font-size:15px;background:#72e6b5;color:#10251d}
button.secondary{background:#31484d;color:white}
.item{margin:12px 0 0;padding:13px;background:#26393d;border:1px solid #405258;border-radius:12px}
.price{font-weight:850;font-size:21px;color:#9bf4c4}.leg{padding-top:7px;font-size:14px;line-height:1.5}
#feedback{min-height:20px;color:#b9f3da;font-size:14px}
.notice{border-left:3px solid #e2b568;background:#292924;padding:11px 12px;border-radius:5px;font-size:13px;color:#eee1cb}
</style>
</head>
<body>
<main>
<div class="eyebrow">LIVE BETTING ALERTS · BETA</div>
<h1>Live αγώνες και ειδοποιήσεις στο κινητό</h1>
<p>Φίλτρο δύο διαφορετικών ποδοσφαιρικών αγώνων, συνολική απόδοση πάνω από 3,00. Χωρίς αυτόματο ποντάρισμα.</p>
<section class="card">
<h2>⚽ Ζωντανές αποδόσεις</h2>
<div id="liveStatus" class="big" role="status">Έλεγχος σύνδεσης…</div>
<div id="checked" class="muted"></div>
<div id="liveItems"></div>
<button class="secondary" id="checkNow">Έλεγχος διαθέσιμων αγώνων</button>
<p class="muted">Η σελίδα ελέγχει για ενημερώσεις κάθε λεπτό όταν παραμένει ανοιχτή. Για το δωρεάν API, τα δεδομένα ανανεώνονται από την πηγή έως κάθε 30 λεπτά. Μπορεί να μην είναι πλέον διαθέσιμες οι εμφανιζόμενες τιμές.</p>
</section>
<section class="card">
<h2>🔔 Ειδοποιήσεις Chrome</h2>
<p class="muted">Δοκίμασε ξανά ότι επιτρέπονται. Οι αυτόματες ειδοποιήσεις υποψήφιων συνδυασμών αυτής της έκδοσης χρειάζονται την ιστοσελίδα ανοιχτή.</p>
<button id="enable">Ενεργοποίηση ειδοποιήσεων</button>
<button id="test" class="secondary">Δοκιμαστική ειδοποίηση</button>
<p id="feedback" role="status" aria-live="polite"></p>
</section>
<section class="card">
<h2>🏀 Μπάσκετ</h2><p class="muted">Στο επόμενο στάδιο: ξεχωριστή πηγή με επιβεβαιωμένες live αποδόσεις μπάσκετ. Η API-Basketball δεν παρέχει τον ίδιο τύπο live odds στο επιλεγμένο endpoint.</p>
</section>
<p class="notice">Οι αριθμοί είναι ενδεικτικοί συνδυασμοί από μία πηγή δεδομένων, όχι «σίγουρα» ή αποδεδειγμένα value bets. Δεν επιβεβαιώνεται ότι μία στοιχηματική εταιρεία προσφέρει ταυτόχρονα και τα δύο σκέλη. Έλεγξε τις πραγματικές αποδόσεις πριν από οποιαδήποτε απόφαση.</p>
</main>
<script>
const feedback = document.getElementById('feedback');
let swRegistration = null;
let previousIds = new Set();
let firstPoll = true;
async function registerWorker(){
  if(!('serviceWorker' in navigator))throw Error('Δεν υποστηρίζονται service workers. Άνοιξε με Chrome.');
  if(!swRegistration)swRegistration=await navigator.serviceWorker.register('/sw.js');
  return swRegistration;
}
async function requestAccess(){
  if(!('Notification' in window))throw Error('Δεν υποστηρίζονται ειδοποιήσεις σε αυτόν τον browser.');
  const r = await registerWorker();
  const p = Notification.permission==='default'?await Notification.requestPermission():Notification.permission;
  if(p!=='granted')throw Error('Οι ειδοποιήσεις δεν έχουν επιτραπεί για την ιστοσελίδα.');
  return r;
}
document.getElementById('enable').addEventListener('click',async()=>{
  try{await requestAccess();feedback.textContent='✓ Οι ειδοποιήσεις είναι ενεργοποιημένες.'}
  catch(e){feedback.textContent=e.message}
});
document.getElementById('test').addEventListener('click',async()=>{
  try{const r=await requestAccess();await r.showNotification('Live Betting Alerts · Δοκιμή',{
    body:'Οι ειδοποιήσεις λειτουργούν! Δεν είναι πραγματική πρόταση στοιχήματος.',
    tag:'live-betting-alerts-test',data:{url:'/'}
  });feedback.textContent='✓ Εστάλη δοκιμαστική ειδοποίηση.'}
  catch(e){feedback.textContent=e.message}
});
let checking = false;
async function checkLive(){
  if(checking)return;checking=true;
  const status = document.getElementById('liveStatus');
  const items = document.getElementById('liveItems');
  try{
    const resp=await fetch('/api/alerts',{cache:'no-store'});
    if(!resp.ok)throw Error('HTTP '+resp.status);
    const data=await resp.json();
    items.replaceChildren();
    if(data.status==='missing_key'){
      status.textContent='Αναμονή για API key';
    }else if(!data.connected){
      status.textContent='Προσωρινό πρόβλημα σύνδεσης';
    }else{
      status.textContent=data.alerts.length+' υποψήφιοι συνδυασμοί';
    }
    document.getElementById('checked').textContent=(data.message||'')+(data.checked_at?' · Έλεγχος: '+new Date(data.checked_at).toLocaleTimeString('el-GR'): '');
    if(data.connected && !data.alerts.length){
      const p=document.createElement('p');p.className='muted';
      p.textContent='Δεν υπάρχουν αυτή τη στιγμή συνδυασμοί που καλύπτουν το φίλτρο.';
      items.appendChild(p);
    }
    const currentIds = new Set();
    for(const alert of data.alerts||[]){
      currentIds.add(alert.id);
      const div=document.createElement('div');div.className='item';
      const headline=document.createElement('div');headline.className='price';
      headline.textContent='Διπλό: '+alert.combined_odd.toFixed(2).replace('.',',');
      div.appendChild(headline);
      for(const leg of alert.legs){
        const line=document.createElement('div');line.className='leg';
        line.textContent=leg.match+' ('+leg.minute+'′) · '+leg.market+' · '+leg.selection+' @ '+leg.odd.toFixed(2);
        div.appendChild(line);
      }
      items.appendChild(div);
      if(!firstPoll && !previousIds.has(alert.id) && Notification.permission==='granted'){
        try{
          const r=await registerWorker();
          await r.showNotification('Live Betting Alerts · Υποψήφιο διπλό',{
            body:alert.legs.map(x=>x.match+' '+x.selection).join(' + ')+' · '+alert.combined_odd.toFixed(2),
            tag:'match-'+alert.id,data:{url:'/'}
          });
        }catch(e){feedback.textContent='Πρόβλημα αυτόματης ειδοποίησης: '+e.message}
      }
    }
    previousIds = currentIds;firstPoll=false;
  }catch(e){status.textContent='Σφάλμα φόρτωσης';document.getElementById('checked').textContent=e.message}
  finally{checking=false}
}
document.getElementById('checkNow').addEventListener('click',checkLive);
checkLive();setInterval(checkLive,60000);
</script>
</body></html>'''

WORKER = """self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(clients.matchAll({type: 'window', includeUncontrolled: true}).then((wins) => {
    const current = wins.find(w => w.url.startsWith(self.location.origin));
    if (current) return current.focus();
    return clients.openWindow('/');
  }));
});
"""

@app.get('/')
def index():
    return render_template_string(PAGE)

@app.get('/health')
def health():
    return jsonify(status='ok', service='live-betting-alerts')

@app.get('/api/alerts')
def alerts():
    return jsonify(get_live_snapshot())

@app.get('/sw.js')
def service_worker():
    return Response(WORKER, mimetype='application/javascript', headers={'Cache-Control': 'no-cache', 'Service-Worker-Allowed':'/'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT','10000')))
