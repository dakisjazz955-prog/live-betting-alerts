"""Licensed API-SPORTS in-play football odds; no fabricated signals."""
from __future__ import annotations

import itertools
import math
import os
import threading
import time
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
import json

API_ROOT = "https://v3.football.api-sports.io"
_LOCK = threading.Lock()
_CACHE = {"at": 0.0, "result": None}


def _fetch(path: str, api_key: str):
    req = Request(API_ROOT + path, headers={"x-apisports-key": api_key, "Accept": "application/json"})
    try:
        with urlopen(req, timeout=12) as r:
            payload = json.load(r)
    except HTTPError as e:
        raise ValueError(f"Η υπηρεσία δεδομένων επέστρεψε HTTP {e.code}.") from e
    except (URLError, TimeoutError, OSError) as e:
        raise ValueError("Δεν ήταν εφικτή η σύνδεση με την υπηρεσία live δεδομένων.") from e
    if payload.get("errors"):
        raise ValueError("Η API-Sports επέστρεψε σφάλμα ή όριο χρήσης. Έλεγξε το κλειδί και το πακέτο σου.")
    return payload.get("response", [])


def _positive_price(value):
    try:
        price = float(str(value).replace(",", "."))
    except (ValueError, TypeError):
        return None
    return price if math.isfinite(price) and 1.01 <= price <= 20 else None


def build_alerts(odds_rows, fixture_rows, min_combo=3.0):
    """Only combine different events; show quoted prices, not value/profit predictions."""
    lookup = {}
    for match in fixture_rows:
        key = str(match.get("fixture", {}).get("id", ""))
        if not key:
            continue
        teams = match.get("teams") or {}
        lookup[key] = {
            "home": (teams.get("home") or {}).get("name"),
            "away": (teams.get("away") or {}).get("name"),
        }
    selections = []
    for event in odds_rows:
        status = event.get("status") or {}
        if status.get("blocked") or status.get("finished") or status.get("stopped"):
            continue
        match = event.get("fixture") or {}
        fixture_id = str(match.get("id") or "")
        if not fixture_id:
            continue
        elapsed = (match.get("status") or {}).get("elapsed")
        # Skip pre-game markets and extremely late football prices.
        if not isinstance(elapsed, (float, int)) or elapsed < 1 or elapsed > 88:
            continue
        info = lookup.get(fixture_id) or {}
        tinfo = event.get("teams") or {}
        home = info.get("home") or str((tinfo.get("home") or {}).get("name") or (tinfo.get("home") or {}).get("id") or "Γηπεδούχος")
        away = info.get("away") or str((tinfo.get("away") or {}).get("name") or (tinfo.get("away") or {}).get("id") or "Φιλοξενούμενος")
        odds = event.get("odds") or []
        for market in odds:
            market_name = str(market.get("name") or "").lower()
            if not ("winner" in market_name or "1x2" in market_name or "match result" in market_name or "fulltime result" in market_name or "full time result" in market_name):
                continue
            if any(label in market_name for label in ("half", "extra", "quarter", "period", "corner", "card", "penalty")):
                continue
            # Prefer main line when duplicate labels exist.
            by_side = {}
            for value in market.get("values") or []:
                if value.get("suspended"):
                    continue
                pick = str(value.get("value") or "").strip()
                if not pick or pick.lower() in {"over", "under", "yes", "no"}:
                    continue
                price = _positive_price(value.get("odd"))
                if price is None or not 1.35 <= price <= 2.5:
                    continue
                key = pick.casefold()
                if key not in by_side or (value.get("main") is True and not by_side[key].get("main")):
                    by_side[key] = {"pick": pick, "price": price, "main": value.get("main") is True}
            for candidate in by_side.values():
                selections.append({
                    "fixture_id": fixture_id, "match": f"{home} – {away}",
                    "minute": int(elapsed), "market": str(market.get("name") or ""),
                    "selection": candidate["pick"], "odd": candidate["price"],
                })
    # Restrict combinations to two separate fixtures, with no claim they share a bookmaker.
    combos = []
    for a, b in itertools.combinations(selections, 2):
        if a["fixture_id"] == b["fixture_id"]:
            continue
        combined = round(a["odd"] * b["odd"], 2)
        if combined > min_combo:
            combos.append({"id": ":".join(sorted((a["fixture_id"]+"/"+a["selection"], b["fixture_id"]+"/"+b["selection"]))),
                           "combined_odd": combined, "legs": [a, b]})
    # Closest to configured minimum first (not a model of betting value).
    combos.sort(key=lambda c: c["combined_odd"])
    return combos[:12]


def get_live_snapshot():
    key = os.environ.get("API_SPORTS_KEY", "").strip()
    if not key:
        return {"connected": False, "alerts": [], "status": "missing_key", "message": "Χρειάζεται API_SPORTS_KEY στα Environment του Render.", "checked_at": None}
    # 15 minutes protects small free daily quotas. Raise frequency only after reviewing API plan.
    ttl = max(60, int(os.environ.get("ODDS_REFRESH_SECONDS", "1800")))
    with _LOCK:
        if _CACHE["result"] is not None and time.monotonic() - _CACHE["at"] < ttl:
            return _CACHE["result"]
        try:
            odds = _fetch("/odds/live", key)
            fixtures = _fetch("/fixtures?live=all", key)
            alerts = build_alerts(odds, fixtures)
            result = {"connected": True, "alerts": alerts, "status": "ok", "live_events_with_odds": len(odds),
                      "checked_at": datetime.now(timezone.utc).isoformat(), "cache_seconds": ttl,
                      "message": "Οι συνδυασμοί είναι ενδεικτικοί, όχι τεκμηριωμένα value bets. Επιβεβαίωσε τις αποδόσεις στον bookmaker."}
        except ValueError as exc:
            result = {"connected": False, "alerts": [], "status": "provider_error", "checked_at": None, "message": str(exc)}
        _CACHE.update(at=time.monotonic(), result=result)
        return result
