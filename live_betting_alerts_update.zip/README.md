# Live Betting Alerts — live-football integration

## Installation on Render

Upload `app.py` and `live_odds.py` **together**, replacing the old `app.py` in the repository root. Keep the existing `requirements.txt` and `render.yaml` unchanged. Render will redeploy automatically if GitHub auto-deploy is enabled.

In Render service **Environment** add a secret environment variable:

- `API_SPORTS_KEY` = the API key from [API-Sports](https://dashboard.api-football.com/) for API-Football v3.

Do **not** put the key inside source code, GitHub, chat messages, or HTML. The API provider's free plan is capped at 100 calls/day; this app makes **2 calls per refresh** and caches each snapshot for 1800 seconds (30 minutes) by default, so at most 96/day if continuously active with one web process. Additional unrelated calls count toward the provider's limit. A sleeping Render instance won't scan matches; there is no background schedule.

Optional environment setting `ODDS_REFRESH_SECONDS` changes the server cache interval (seconds) only if your plan can support the corresponding API usage. Use a single gunicorn worker to maintain a shared per-process cache, e.g. the existing default command `gunicorn --bind 0.0.0.0:$PORT app:app` (one worker by default).

## Available in this release
- Working Android Chrome test notifications retained.
- Real API-Sports in-play football odds `GET /odds/live`, plus `GET /fixtures?live=all` for team names.
- Filters live, unblocked, non-suspended full-time winner selections (single leg odds 1.35–2.50) and finds two legs from different fixtures with combined quoted price **greater than 3.00**.
- Displays tentative combinations and notifies of newly appearing combinations **only while the page remains open**. First fetch displays combinations but deliberately sends no notification to avoid unnecessary alerts.
- Caches paid/free provider requests and displays timestamp.
- Does not place bets, infer win probability, or claim value betting.

## Still to implement
- Persistent server-side Web Push when the browser is closed (requires VAPID keys, subscription persistence, and scheduled scanning/always-on hosting).
- Separate live-basketball odds source; API-Basketball's documented `odds` endpoint is pre-match, not in-play.
- Dedicated bookmaker matching; API-Sports in-play odds don't assert that both legs are quoted by the same bookmaker, so any combination must be verified.
- Additional configurable analysis rules (probability, live stats, changes in odds, time bands, confidence).

## URLs
- `/` Mobile frontend
- `/health` Server liveness
- `/api/alerts` Actual sourced live data status (empty if key missing or no matching events)

## Safety & accuracy
Odds can change immediately; providers may be delayed, and a 30-minute polling cache is for a free-tier **demonstration**, not for actionably timely live-betting decisions. No data is invented if the provider is unavailable.
