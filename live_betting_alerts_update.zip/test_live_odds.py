import unittest
from live_odds import build_alerts

class TestSignals(unittest.TestCase):
    def test_doubles_separate_fixtures(self):
        def match(i, odd):
            return {'fixture':{'id':i,'status':{'elapsed':35}},'status':{'finished':False,'blocked':False},
                    'teams':{'home':{'id':i},'away':{'id':i+1}},
                    'odds':[{'name':'Match Winner','values':[{'value':'Home','odd':str(odd)}]}]}
        fixtures=[{'fixture':{'id':i},'teams':{'home':{'name':f'Team {i}'},'away':{'name':'Opponent'}}} for i in [1,3]]
        got=build_alerts([match(1,1.85),match(3,1.75)],fixtures)
        self.assertEqual(len(got),1)
        self.assertEqual(got[0]['combined_odd'],3.24)
        self.assertIn('Team 1',got[0]['legs'][0]['match'])
    def test_blocked_or_suspended(self):
        row={'fixture':{'id':1,'status':{'elapsed':40}},'status':{'blocked':True},'odds':[{'name':'Match Winner','values':[{'value':'Home','odd':'1.9'}]}]}
        self.assertEqual(build_alerts([row,row],[]),[])

if __name__ == '__main__': unittest.main()
