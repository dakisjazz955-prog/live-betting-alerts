# Live Betting Alerts — Web Push upgrade

Greek-language mobile Flask app, no betting automation.

## Implemented

- Permission and device push subscription using Android Chrome / Push API.
- Service worker receives **server-sent push notifications** even while the web page is closed.
- An **immediate local test**, plus a **40-second delayed server push test**: tap it and press Home before the message arrives.
- Push subscriptions saved in SQLite (temporary default) or PostgreSQL when `DATABASE_URL` is configured.
- VAPID key generated automatically for easy demonstration. Optional fixed `VAPID_PRIVATE_KEY` in Render's environment.
- Protected `/api/push/send` endpoint for **future** integrations, disabled until `PUSH_SEND_TOKEN` is set.
- `/api/alerts` returns `[]`: **no live scores/odds provider is connected**.

## Install on the existing Render app

Replace **`app.py`**, **`requirements.txt`**, and **`README.md`** in the existing repository with the files from this upgrade (do not upload the ZIP itself). The current `render.yaml` remains valid:

- Build: `pip install -r requirements.txt`
- Start: `gunicorn --bind 0.0.0.0:$PORT app:app`

Auto-deploy runs only if enabled for the connected GitHub branch. Otherwise trigger **Manual Deploy > Deploy latest commit** in Render.

After deployment, open https://live-betting-alerts.onrender.com in Android Chrome and tap **Ενεργοποίηση ειδοποιήσεων Web Push**, then **Δοκιμή με κλειστή σελίδα (σε 40″)** and press Home immediately. It may not arrive if the server restarts during the timer.

## What is required for reliable production background alerts

1. **Stable VAPID private key**: generate a P-256 key locally, store its *private* PEM in a Render environment variable named `VAPID_PRIVATE_KEY` (never commit this key to GitHub); optionally set `VAPID_SUBJECT` to a contact `mailto:` URI or an HTTPS URL. Once changed, visit the app again and re-enable push. The app derives the public key automatically.
2. **Persistent database**: assign a PostgreSQL connection string in `DATABASE_URL`. Without it, local SQLite data is erased whenever an ephemeral Render instance restarts or sleeps.
3. **Always-running hosting + trusted trigger**: Free Render Web Service spins down after 15 minutes idle, stopping timers and any live monitoring. Use suitable always-on hosting for reliable delivery.
4. **Licensed live sports/odds feed**: integrate real football/basketball data and an event-monitor to call the protected send endpoint. Alerts are not yet generated automatically.

The optional `PUSH_SEND_TOKEN` must be stored as a secret Render environment variable. A trusted backend can POST `/api/push/send` with `Authorization: Bearer <PUSH_SEND_TOKEN>` and JSON `{"title":"...", "body":"..."}`. Do not put the token in the browser/client JS. This endpoint is not for public traffic.

Notifications are informational only. No automatic wagers; no prediction of positive return.
