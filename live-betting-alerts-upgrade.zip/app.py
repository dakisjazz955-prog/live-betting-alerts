"""Live Betting Alerts — mobile Web Push test and future alert delivery.

No real odds or live scores are connected. Server-side push allows a delayed
background TEST while Chrome is closed; persistent delivery needs a stable VAPID
key, persistent database and an always-on server.
"""
import base64
import hashlib
import hmac
import json
import logging
import os
import sqlite3
import threading
import time
from urllib.parse import urlsplit

from cryptography.hazmat.primitives import serialization
from flask import Flask, Response, jsonify, render_template_string, request
from py_vapid import Vapid
from pywebpush import WebPushException, webpush

app = Flask(__name__)
logger = logging.getLogger(__name__)

VAPID_SUBJECT = os.environ.get("VAPID_SUBJECT", "https://live-betting-alerts.onrender.com")
VAPID_PRIVATE_KEY = os.environ.get("VAPID_PRIVATE_KEY", "").strip()
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
SQLITE_PATH = os.environ.get("PUSH_DB_PATH", "/tmp/live-betting-alerts.sqlite3")
ALLOWED_PUSH_HOSTS = {
    "fcm.googleapis.com", "android.googleapis.com",
    "updates.push.services.mozilla.com", "web.push.apple.com"
}
DELAY_SECONDS = 40

vapid = Vapid()
if VAPID_PRIVATE_KEY:
    if VAPID_PRIVATE_KEY.startswith("-----BEGIN"):
        private_key = serialization.load_pem_private_key(
            VAPID_PRIVATE_KEY.replace("\\n", "\n").encode(), password=None
        )
    else:
        padded = VAPID_PRIVATE_KEY + "=" * (-len(VAPID_PRIVATE_KEY) % 4)
        private_key = serialization.load_der_private_key(
            base64.urlsafe_b64decode(padded), password=None
        )
    vapid.private_key = private_key
else:
    vapid.generate_keys()  # DEMO ONLY: new key on every free Render restart.

PUBLIC_KEY = base64.urlsafe_b64encode(
    vapid.public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
).rstrip(b"=").decode("ascii")
TEST_LOCK = threading.Lock()
PENDING_TESTS = set()
LAST_TEST = {}


def open_database():
    if DATABASE_URL:
        import psycopg
        db = psycopg.connect(DATABASE_URL, connect_timeout=5)
        placeholder = "%s"
    else:
        db = sqlite3.connect(SQLITE_PATH, timeout=5)
        placeholder = "?"
    db.execute("CREATE TABLE IF NOT EXISTS subscriptions "
               "(endpoint TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at BIGINT NOT NULL)")
    db.commit()
    return db, placeholder


def validate_subscription(data):
    if not isinstance(data, dict):
        raise ValueError("Λείπουν τα στοιχεία της συσκευής.")
    endpoint = data.get("endpoint")
    keys = data.get("keys")
    if not isinstance(endpoint, str) or len(endpoint) > 2500:
        raise ValueError("Μη έγκυρη διεύθυνση ειδοποιήσεων.")
    parsed = urlsplit(endpoint)
    if (parsed.scheme != "https" or parsed.hostname not in ALLOWED_PUSH_HOSTS
            or parsed.port not in (None, 443)):
        raise ValueError("Μη υποστηριζόμενος πάροχος ειδοποιήσεων.")
    if not isinstance(keys, dict) or not isinstance(keys.get("p256dh"), str) or not isinstance(keys.get("auth"), str):
        raise ValueError("Λείπουν τα κλειδιά ειδοποιήσεων.")
    if not 40 <= len(keys["p256dh"]) <= 200 or not 10 <= len(keys["auth"]) <= 200:
        raise ValueError("Μη έγκυρα κλειδιά ειδοποιήσεων.")
    return {"endpoint": endpoint, "keys": {"p256dh": keys["p256dh"], "auth": keys["auth"]}}


def save_subscription(sub):
    db, p = open_database()
    try:
        db.execute(
            f"INSERT INTO subscriptions(endpoint,payload,updated_at) VALUES({p},{p},{p}) "
            "ON CONFLICT(endpoint) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at",
            (sub["endpoint"], json.dumps(sub), int(time.time())),
        )
        db.commit()
    finally:
        db.close()


def remove_subscription(endpoint):
    db, p = open_database()
    try:
        db.execute(f"DELETE FROM subscriptions WHERE endpoint={p}", (endpoint,))
        db.commit()
    finally:
        db.close()


def deliver_push(sub, title, body):
    payload = json.dumps({"title": title, "body": body, "url": "/"}, ensure_ascii=False)
    try:
        webpush(subscription_info=sub, data=payload, vapid_private_key=vapid,
                vapid_claims={"sub": VAPID_SUBJECT}, ttl=120, timeout=12)
        return True
    except WebPushException as exc:
        status = getattr(getattr(exc, "response", None), "status_code", None)
        if status in (404, 410):
            try:
                remove_subscription(sub["endpoint"])
            except Exception:
                logger.exception("Failed to clean expired subscription")
        logger.warning("Web Push failed with HTTP status %s", status)
    except Exception:
        logger.exception("Web Push delivery failed")
    return False


def send_test_later(sub, key):
    try:
        deliver_push(sub, "Live Betting Alerts · Παρασκήνιο",
                     "Η ειδοποίηση ήρθε από τον διακομιστή. Δεν είναι πρόταση στοιχήματος.")
    finally:
        with TEST_LOCK:
            PENDING_TESTS.discard(key)


PAGE = r"""<!doctype html>
<html lang="el">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#101b20">
<title>Live Betting Alerts</title>
<style>
:root { color-scheme:dark; font-family:system-ui,-apple-system,'Segoe UI',sans-serif; }
body { margin:0; background:#101b20; color:#f5f7f7; }
.shell { max-width:580px; margin:0 auto; padding:28px 20px 45px; }
h1 { font-size:30px; line-height:1.12; letter-spacing:-.7px; margin:24px 0 12px; }
p { color:#b5c2c5; line-height:1.6; }
.eyebrow { color:#6ce6b4; font-size:12px; font-weight:800; letter-spacing:2px; }
.card { background:#1c2a30; border:1px solid #33434b; border-radius:18px; padding:19px; margin-top:16px; }
.line { display:flex; align-items:center; justify-content:space-between; gap:12px; }
.tag { color:#ffd796; background:#4a3921; padding:5px 10px; border-radius:20px; font-size:12px; }
h2 { font-size:17px; margin:0 0 9px; }
.muted { color:#b5c2c5; font-size:14px; }
.number { font-size:28px; font-weight:800; margin:7px 0; }
.buttons { display:grid; gap:10px; margin-top:18px; }
button { border:0; border-radius:12px; padding:15px 17px; font-size:15px; font-weight:750; cursor:pointer; }
.primary { background:#69e5b3; color:#10241c; }
.secondary { color:#f3faf7; background:#2f474e; }
#feedback { min-height:20px; font-size:14px; color:#b7f5d9; }
.notice { border-left:3px solid #f3b95c; padding:10px 13px; background:#2d2925; font-size:13px; color:#e7d9c7; }
.foot { font-size:12px; padding-top:14px; }
</style>
</head>
<body>
<main class="shell">
<div class="eyebrow">LIVE BETTING ALERTS · BETA</div>
<h1>Ειδοποιήσεις αγώνων στο κινητό</h1>
<p>Δοκίμασε πραγματικές ειδοποιήσεις Web Push στο Android, ακόμη και με κλειστή τη σελίδα.</p>
<div class="card">
<div class="line"><h2>Κατάσταση συστήματος</h2><span class="tag">Δοκιμαστική έκδοση</span></div>
<div class="number">Web Push · Δοκιμή</div>
<div class="muted">Δεν υπάρχει ακόμη σύνδεση με ζωντανές αποδόσεις ή πραγματικά σήματα.</div>
</div>
<div class="card">
<h2>Αρχικές προτιμήσεις</h2>
<p>⚽ Ποδόσφαιρο &nbsp; 🏀 Μπάσκετ</p>
<p>Στόχος: συνδυασμοί δύο επιλογών με συνολική απόδοση πάνω από 3,00.</p>
<p class="muted">Μόνο ειδοποιήσεις — ποτέ αυτόματη τοποθέτηση στοιχήματος.</p>
</div>
<div class="card">
<h2>Δοκιμή ειδοποιήσεων</h2>
<p class="muted">Πάτησε πρώτα ενεργοποίηση. Για να δοκιμάσεις ειδοποίηση όταν ο Chrome είναι στο παρασκήνιο, πάτησε το τρίτο κουμπί και γύρισε στην αρχική οθόνη του κινητού.</p>
<div class="buttons">
<button class="primary" id="enable">Ενεργοποίηση ειδοποιήσεων Web Push</button>
<button class="secondary" id="test">Άμεση δοκιμαστική ειδοποίηση</button>
<button class="secondary" id="background">Δοκιμή με κλειστή σελίδα (σε 40″)</button>
</div>
<p id="feedback" role="status" aria-live="polite"></p>
</div>
<p class="notice" id="notice">Οι δοκιμαστικές ειδοποιήσεις δεν αποτελούν στοιχηματικές προτάσεις. Στο δωρεάν Render η αποστολή δεν είναι ακόμη εγγυημένη μετά από επανεκκίνηση ή αδράνεια του διακομιστή.</p>
<p class="foot">Live Betting Alerts · Χωρίς αυτόματα στοιχήματα</p>
</main>
<script>
const feedback = document.getElementById('feedback');
let swRegistration = null;
const showError = error => { feedback.textContent = '⚠ ' + (error.message || String(error)); };
function decodeBase64Url(key) {
  const base64 = key.replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64.padEnd(Math.ceil(base64.length / 4) * 4, '='));
  return Uint8Array.from(raw, char => char.charCodeAt(0));
}
async function worker() {
  if (!('serviceWorker' in navigator)) throw Error('Απαιτείται Chrome με υποστήριξη service workers.');
  if (!swRegistration) swRegistration = await navigator.serviceWorker.register('/sw.js', {updateViaCache:'none'});
  return swRegistration;
}
async function allow() {
  if (!('Notification' in window) || !('PushManager' in window)) throw Error('Χρησιμοποίησε τον Chrome στο Android.');
  const reg = await worker();
  const permission = Notification.permission === 'default' ? await Notification.requestPermission() : Notification.permission;
  if (permission !== 'granted') throw Error('Οι ειδοποιήσεις δεν έχουν επιτραπεί.');
  return reg;
}
async function subscribePush() {
  const reg = await allow();
  const r = await fetch('/api/push/public-key', {cache:'no-store'});
  if (!r.ok) throw Error('Ο διακομιστής δεν είναι έτοιμος.');
  const config = await r.json();
  let sub = await reg.pushManager.getSubscription();
  const oldKey = localStorage.getItem('live-betting-vapid-key');
  if (sub && oldKey !== config.public_key) {
    await sub.unsubscribe();
    sub = null;
  }
  if (!sub) sub = await reg.pushManager.subscribe({userVisibleOnly:true, applicationServerKey:decodeBase64Url(config.public_key)});
  localStorage.setItem('live-betting-vapid-key', config.public_key);
  const saved = await fetch('/api/push/subscribe', {
    method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(sub)
  });
  const response = await saved.json();
  if (!saved.ok) throw Error(response.error || 'Δεν αποθηκεύτηκε η συνδρομή.');
  return {reg, sub, config};
}
document.getElementById('enable').addEventListener('click', async () => {
  feedback.textContent = 'Εγγραφή συσκευής…';
  try {
    const {config} = await subscribePush();
    feedback.textContent = '✓ Η συσκευή γράφτηκε για Web Push.' + (config.temporary_key || !config.durable_storage ? ' (Προσωρινή λειτουργία Render.)' : '');
  } catch (error) { showError(error); }
});
document.getElementById('test').addEventListener('click', async () => {
  try {
    const reg = await allow();
    await reg.showNotification('Live Betting Alerts · Δοκιμή', {
      body:'Η άμεση ειδοποίηση λειτουργεί. Δεν είναι πρόταση στοιχήματος.',
      data:{url:'/'}
    });
    feedback.textContent = '✓ Στάλθηκε η άμεση ειδοποίηση.';
  } catch (error) { showError(error); }
});
document.getElementById('background').addEventListener('click', async () => {
  feedback.textContent = 'Προγραμματισμός δοκιμής στον διακομιστή…';
  try {
    const {sub} = await subscribePush();
    const r = await fetch('/api/push/test', {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(sub)
    });
    const result = await r.json();
    if (!r.ok) throw Error(result.error || 'Η δοκιμή απέτυχε.');
    feedback.textContent = '✓ Προγραμματίστηκε ειδοποίηση σε ' + result.delay_seconds + ' δευτερόλεπτα. Πάτησε Home τώρα.';
  } catch (error) { showError(error); }
});
</script>
</body>
</html>"""

WORKER = r"""self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (_) {}
  event.waitUntil(self.registration.showNotification(
    String(data.title || 'Live Betting Alerts'),
    {body: String(data.body || 'Νέα ειδοποίηση.'), data: {url: '/'}}
  ));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(windows => {
    const open = windows.find(w => w.url.startsWith(self.location.origin));
    if (open) return open.focus();
    return clients.openWindow('/');
  }));
});
"""


@app.get('/')
def index():
    return render_template_string(PAGE)


@app.get('/health')
def health():
    return jsonify(status='ok', service='live-betting-alerts')


@app.get('/api/alerts')
def alerts():
    return jsonify(alerts=[], live_data_connected=False)


@app.get('/sw.js')
def service_worker():
    return Response(WORKER, mimetype='application/javascript',
                    headers={'Cache-Control': 'no-store', 'Service-Worker-Allowed': '/'})


@app.get('/api/push/public-key')
def get_public_key():
    return jsonify(public_key=PUBLIC_KEY, temporary_key=not bool(VAPID_PRIVATE_KEY),
                   durable_storage=bool(DATABASE_URL), delay_seconds=DELAY_SECONDS)


@app.post('/api/push/subscribe')
def subscribe():
    try:
        sub = validate_subscription(request.get_json(silent=True))
        save_subscription(sub)
        return jsonify(ok=True, persistent=bool(DATABASE_URL))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    except Exception:
        logger.exception('Could not store push subscription')
        return jsonify(error='Δεν αποθηκεύτηκε η συσκευή.'), 503


@app.post('/api/push/unsubscribe')
def unsubscribe():
    try:
        sub = validate_subscription(request.get_json(silent=True))
        remove_subscription(sub['endpoint'])
        return jsonify(ok=True)
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    except Exception:
        logger.exception('Could not remove push subscription')
        return jsonify(error='Η διαγραφή απέτυχε.'), 503


@app.post('/api/push/test')
def schedule_background_test():
    try:
        sub = validate_subscription(request.get_json(silent=True))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    key = hashlib.sha256(sub['endpoint'].encode()).hexdigest()
    with TEST_LOCK:
        now = time.monotonic()
        for old_key, last in list(LAST_TEST.items()):
            if now - last > 180:
                del LAST_TEST[old_key]
        if (len(PENDING_TESTS) >= 10 or key in PENDING_TESTS
                or now - LAST_TEST.get(key, -1000) < 60):
            return jsonify(error='Υπάρχει ήδη δοκιμή. Δοκίμασε αργότερα.'), 429
        LAST_TEST[key] = now
        PENDING_TESTS.add(key)
    timer = threading.Timer(DELAY_SECONDS, send_test_later, args=(sub, key))
    timer.daemon = True
    timer.start()
    return jsonify(ok=True, delay_seconds=DELAY_SECONDS), 202


@app.post('/api/push/send')
def send_alert():
    """Reserved for a trusted sports-data monitor. Requires a secret token."""
    token = os.environ.get('PUSH_SEND_TOKEN', '')
    if not token:
        return jsonify(error='Η αυτόματη αποστολή δεν έχει ρυθμιστεί.'), 503
    if not hmac.compare_digest(request.headers.get('Authorization', ''), 'Bearer ' + token):
        return jsonify(error='Δεν επιτρέπεται.'), 401
    data = request.get_json(silent=True) or {}
    title, body = data.get('title'), data.get('body')
    if (not isinstance(title, str) or not isinstance(body, str)
            or not (1 <= len(title) <= 100 and 1 <= len(body) <= 400)):
        return jsonify(error='Χρειάζονται τίτλος και κείμενο.'), 400
    try:
        db, _ = open_database()
        try:
            rows = db.execute('SELECT payload FROM subscriptions ORDER BY updated_at DESC LIMIT 100').fetchall()
        finally:
            db.close()
    except Exception:
        logger.exception('Could not fetch subscriptions')
        return jsonify(error='Μη διαθέσιμη αποθήκευση.'), 503
    accepted = sum(deliver_push(json.loads(row[0]), title, body) for row in rows)
    return jsonify(ok=True, attempted=len(rows), accepted=accepted)


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '10000'))
    app.run(host='0.0.0.0', port=port)
